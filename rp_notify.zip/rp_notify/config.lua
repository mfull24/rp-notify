Config = {}

-- Distance maximum pour voir les notifications (en mètres)
Config.DisplayDistance = 10.0

-- Durée d'affichage du texte (en secondes)
Config.DisplayTime = 3

-- Messages personnalisables
Config.Messages = {
    Searching = "fouille ses poches...",
    PauseMenu = "fait une pause..."
}
