local displayNotifications = {}   -- { [playerId] = {msg="...", time=GetGameTimer()} }

-- ▬▬▬ AFFICHAGE 3D ▬▬▬
local function DrawText3D(coords, text, isSelf)
    local zOffset = isSelf and 1.2 or 1.0

    SetDrawOrigin(coords.x, coords.y, coords.z + zOffset, 0)
    SetTextFont(0)
    SetTextProportional(0)
    SetTextScale(0.35, 0.35)
    SetTextColour(255, 255, 255, 255)
    SetTextCentre(true)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end


-- ▬▬▬ RÉCEPTION DE LA NOTIFICATION ▬▬▬
RegisterNetEvent("rp_notify:show")
AddEventHandler("rp_notify:show", function(target, message)
    displayNotifications[target] = {
        msg = message,
        time = GetGameTimer()
    }
end)

-- ▬▬▬ DETECTION TOUCHE TAB ▬▬▬
CreateThread(function()
    while true do
        Wait(0)
        if IsControlJustPressed(0, 37) then -- TAB
            TriggerServerEvent("rp_notify:trigger", Config.Messages.Searching)
        end
    end
end)

-- ▬▬▬ DETECTION MENU PAUSE ▬▬▬
CreateThread(function()
    while true do
        Wait(500)

        if IsPauseMenuActive() then
            TriggerServerEvent("rp_notify:trigger", Config.Messages.PauseMenu)
            Wait(3000) -- éviter spam
        end
    end
end)

-- ▬▬▬ RENDU DES MESSAGES AU-DESSUS DES JOUEURS ▬▬▬
CreateThread(function()
    while true do
        Wait(0)

        local plyPed = PlayerPedId()
        local plyCoords = GetEntityCoords(plyPed)

        for id, data in pairs(displayNotifications) do
            if (GetGameTimer() - data.time) < (Config.DisplayTime * 1000) then
                local targetPed = GetPlayerPed(GetPlayerFromServerId(id))
                if DoesEntityExist(targetPed) then
                    local coords = GetEntityCoords(targetPed)
                    if #(plyCoords - coords) < Config.DisplayDistance then
                        local isSelf = (id == GetPlayerServerId(PlayerId()))
                        DrawText3D(coords, data.msg, isSelf)
                    end
                end
            else
                displayNotifications[id] = nil
            end
        end
    end
end)

-- ▬▬▬ INTÉGRATION QBCORE: INVENTAIRE ▬▬▬
local lastInvNotify = 0
local function notifyInventoryOpen()
    local now = GetGameTimer()
    if now - lastInvNotify > 2000 then -- anti-spam 2s
        lastInvNotify = now
        TriggerServerEvent("rp_notify:trigger", Config.Messages.Searching)
    end
end

-- qb-inventory (variantes selon versions/forks)
RegisterNetEvent('qb-inventory:client:openInventory')
AddEventHandler('qb-inventory:client:openInventory', function(...)
    notifyInventoryOpen()
end)

RegisterNetEvent('qb-inventory:client:OpenInventory')
AddEventHandler('qb-inventory:client:OpenInventory', function(...)
    notifyInventoryOpen()
end)

-- Certains forks utilisent un prefix générique
RegisterNetEvent('inventory:client:openInventory')
AddEventHandler('inventory:client:openInventory', function(...)
    notifyInventoryOpen()
end)
