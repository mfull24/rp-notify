RegisterNetEvent("rp_notify:trigger")
AddEventHandler("rp_notify:trigger", function(message)
    local src = source
    -- Envoi à TOUT LE MONDE, y compris l’émetteur
    TriggerClientEvent("rp_notify:show", -1, src, message)

end)
